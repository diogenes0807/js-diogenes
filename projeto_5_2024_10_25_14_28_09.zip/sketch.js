function setup() { // função de configuração
  createCanvas(400, 400); //criando a tela 
}

function inicializaCores() {
  
  background("white"); //cor de fundo
  fill("black"); //cor do texto 
  textSize(64); //tamanho do texto 
  textAlign(CENTER, CENTER); //onde vai ficar o texto 
}

function draw() { //função de desenhar 
  
  inicializaCores();

  let maximo = width; //tamanho maximo e a largura da palavra
  let minimo = 0; //tamanho minimo 
  // mouseX, 0, width ==> 0, palavra.length
  let palavra = "Caminhante"; //o que vai ser escrito
  let quantidade = map(mouseX, 0, width, 1, palavra.length); //tá vendo onde ta o mouse para mostrar a palavra 
  //console.log(quantidade);
  let parcial = palavra.substring(0, quantidade);
  text(parcial, 200, 200);
  
}
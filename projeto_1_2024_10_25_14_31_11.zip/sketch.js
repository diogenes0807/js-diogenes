function setup() { //função de configuração
  createCanvas(600, 600);// criando a tela
   background("white");//cor do fundo
}


function draw() {//desenho de função
  
  stroke ("blue");//as bordas são da azul
  fill ("red");//preenchimento vermelho
 
  
  // console.log(mouseIsPressed);
  
  if (mouseIsPressed){//podera criar um desenho
    rect(mouseX, mouseY, 20, 35);//almenta e diminui o tamanho da largura
  }
}
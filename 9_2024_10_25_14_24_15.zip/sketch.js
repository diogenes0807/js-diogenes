let palavra;

function setup() { //função de configuração
  createCanvas(400, 400); //criando a tela

  palavra = palavraAleatoria();
  
}

function palavraAleatoria() {
  
  let palavras = ["Caminhante", "Caminho", "Caminha"]; //as palavras para mostrar 
  
  return random(palavras);
}

function inicializaCores() {
  background("white"); //cor de fundo
  fill("black"); //cor de texto
  textSize(64); //tamanho do texto 
  textAlign(CENTER, CENTER); //onde vai ficar o texto
}

function palavraParcial(minimo, maximo) {
  let quantidade = map(mouseX, minimo, maximo, 1, palavra.length); //ta vendo onde ta o mouse para mostra a palavra
  let parcial = palavra.substring(0, quantidade); //quantidade de palavra que sai
  return parcial;
}

function draw() { //função de desenhar 
  
  inicializaCores();

  let texto = palavraParcial(0, width); //quantidade de palavra que sai
    
  text(texto, 200, 200); //muda a pocição
  
}

function modoNoturno(horario) { // aonde liga o modo noturno
  if (horario > 18) {
    console.log("Você precisa ligar o modo escuro!"); //se pasar da 18hr precisa ligr o modo noturno
  } else {
    console.log("Modo noturno não é necessário neste momento."); //se for ante a 18hr não preci ligr o modo noturno
  }
}

modoNoturno(15);
modoNoturno(20);
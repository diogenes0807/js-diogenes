let cor;
let posicaoHorizontal; // x
let posicaoVertical; // y

function setup() {//função de configuração
  createCanvas(400, 400); //criando a tela
   background(color(100,0,0)); //cor de fundo
  cor = color(random(0,255), random(0,255), random(0,255)); //cor aleatoriada da bolinha
  posicaoHorizontal = 200;
  posicaoVertical = 200;
}


function draw() {//função de desenhar 
  
  fill(cor);//cor da bolinha
  circle(posicaoHorizontal,posicaoVertical,50); //tamanho do circulo
 
  
  
  if (mouseX < posicaoHorizontal){
    posicaoHorizontal =  posicaoHorizontal - 10; //velocidade
  }
  
  if (mouseX > posicaoHorizontal){
    posicaoHorizontal =  posicaoHorizontal + 1; //velocidade
  }
  
  if (mouseY < posicaoVertical){//velocidade
    posicaoVertical--;
  }
    
  if (mouseY > posicaoVertical){//velocidade
    posicaoVertical++;
  }
  
  if (mouseIsPressed){//quando o mouse for clicado
    cor = color(random(0,255), random(0,255), random(0,255), random(0,100)); //muda de cor=0pç9  }
    
}
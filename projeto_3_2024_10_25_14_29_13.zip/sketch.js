let cor;
let circuloX; // horizontal
let circuloY; // vertical

function setup() { //função de configuração
  createCanvas(400, 400); //criando a tela
  background(color(100,0,0)); //cor de fundo
  cor = color(random(0,255), random(0,255), random(0,255)); //cor aleatoria da bolinha
  circuloX = [0,0,0];
  circuloY = [random(height), random(height), random(height)];
}

// circuloX = 0,0,0  
// circuloY = 300, 150 , 150




function draw() { //função de desenhar
  
  fill(cor); //cor da bolinha 
  
  //console.log (circuloX.length)
  
  for (let contador in circuloX) {
    // console.log (contador)
  circle(circuloX[contador], circuloY[contador], 50); //velocidade
  circuloX[contador] += random (0,3);//direção aleatoria
  circuloY[contador] += random (-3,3);//direção aleatoria
    
    if (circuloX[contador] >= width){//velocidade da bola
      circuloX[contador] = 0;
      circuloY[contador] = random(height);//velocidade da bola aleatoria
    }
   
  }
 
  
  
  
  
  if (mouseIsPressed){//clique no mouse
    cor = color(random(0,255), random(0,255), random(0,255), random(0,100)); //mude de cor da bola
  }
    
}
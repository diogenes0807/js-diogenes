function setup() { //função de configuração
  createCanvas(400, 400); //criando a tela
}

function draw() { //função de desenhar
  background("white"); //cor de fundo 
  fill("black"); //cor de texto
  textSize(64); //tamanho do texto 
  textAlign(CENTER,CENTER); //onde vai ficar o texto
  
  let maximo = width; //tamanho maximo e a largura da palavra
  let minimo = 0; //tamanho minimo
  //mouseX, 0, width ==> 0, palavra.length
  let palavra = "Caminhante"; //o que vai ser escrito
  let quantidade = map(mouseX, 0, width, 1, palavra.length); //ta vendo onde ta o mouse para mostra a palavra
  //console.log(quantidade);
  let parcial = palavra.substring(0,quantidade); //quantidade de palavra que sai
  text(parcial,200,200); //muda a pocição
  
  // if(mouseX <50) {function setup() {
  // let palavra = "C";
  //text(palavra,200,200);
  //}else if (mouseX <100){
  //let palavra = "Ca";
  // text(palavra,200,200);
  //}else{
  //let palavra = "Caminhante";
  // text (palavra,200,200);
  //}


  
}